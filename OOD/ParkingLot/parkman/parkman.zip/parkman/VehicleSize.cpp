//
//  VehicleSize.cpp
//  parkman
//
//  Created by fakewen on 6/22/17.
//  Copyright © 2017 Koshr. All rights reserved.
//

#include "VehicleSize.hpp"
#include <iostream>
using namespace std;
/*
enum class VehicleSize{
    Compact=1,Large=2,
};*/
