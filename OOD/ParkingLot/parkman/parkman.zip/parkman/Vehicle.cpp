//
//  Vehicle.cpp
//  parkman
//
//  Created by fakewen on 6/22/17.
//  Copyright © 2017 Koshr. All rights reserved.
//

#include "Vehicle.hpp"

#include <iostream>

using namespace std;


